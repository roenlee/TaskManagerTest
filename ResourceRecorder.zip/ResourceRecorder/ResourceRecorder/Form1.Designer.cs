﻿namespace ResourceRecorder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.listView1 = new System.Windows.Forms.ListView();
            this.clnName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clnPID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clnMemPri = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clnMemWork = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clnMemset64 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clnName,
            this.clnPID,
            this.clnMemPri,
            this.clnMemWork,
            this.clnMemset64,
            this.columnHeader1});
            this.listView1.Location = new System.Drawing.Point(38, 33);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(911, 470);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
         //   this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // clnName
            // 
            this.clnName.Text = "名称";
            this.clnName.Width = 320;
            // 
            // clnPID
            // 
            this.clnPID.Text = "PID";
            this.clnPID.Width = 100;
            // 
            // clnMemPri
            // 
            this.clnMemPri.Text = "内存使用Private";
            this.clnMemPri.Width = 100;
            // 
            // clnMemWork
            // 
            this.clnMemWork.Text = "内存使用Work";
            this.clnMemWork.Width = 111;
            // 
            // clnMemset64
            // 
            this.clnMemset64.Width = 103;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Width = 123;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1061, 716);
            this.Controls.Add(this.listView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader clnName;
        private System.Windows.Forms.ColumnHeader clnPID;
        private System.Windows.Forms.ColumnHeader clnMemPri;
        private System.Windows.Forms.ColumnHeader clnMemWork;
        private System.Windows.Forms.ColumnHeader clnMemset64;
        private System.Windows.Forms.ColumnHeader columnHeader1;
    }
}

