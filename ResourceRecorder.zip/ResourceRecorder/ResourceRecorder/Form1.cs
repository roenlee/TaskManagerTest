﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Management;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using WindowsFormsApplication1;

namespace ResourceRecorder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            // Stopwatch watchTime = Stopwatch.StartNew();

             GetCurrentInfo();

            //获取当前进程对象
            //Process curPro = Process.GetCurrentProcess();
            //PerformanceCounter curpcp = new PerformanceCounter("Process", "Working Set - Private", curPro.ProcessName);
            //PerformanceCounter curpc = new PerformanceCounter("Process", "Working Set", curPro.ProcessName);
            //PerformanceCounter curtime = new PerformanceCounter("Process", "% Processor Time", curPro.ProcessName);

            //上次记录CPU的时间
          //  TimeSpan prevCputTime = TimeSpan.Zero;
            //Sleep的时间间隔
           // int interval = 1000;

          //  PerformanceCounter totalcpu = new PerformanceCounter("Processor", "% Processor Time", "_Total");

          // SystemInfo sys = new SystemInfo();
            //const int KB_DIV = 1024;
            //const int MB_DIV = 1024 * 1024;
            //const int GB_DIV = 1024 * 1024 * 1024;

           

            //    listView1.Items.Clear();
            //    Process[] pro = Process.GetProcesses();
            //    foreach (Process item in pro)
            //    {
            //         PerformanceCounter curpcp = new PerformanceCounter("Process", "Working Set - Private", item.ProcessName);
            //         PerformanceCounter curpc = new PerformanceCounter("Process", "Working Set", item.ProcessName);


            //        item.Refresh();
            //        string[] str1 =
            //            {
            //            item.ProcessName,
            //            item.Id.ToString(),
            //            ((double)(item.WorkingSet64/KB_DIV)).ToString("#.##")+ "K",
            //            (curpcp.NextValue()/KB_DIV).ToString("#.##")+ "K",
            //            (curpc.NextValue()/KB_DIV).ToString("#.##")+ "K",

            //        };
            //    }

            

           


        }


        private void GetCurrentInfo()
        {
            listView1.Items.Clear();

            Process[] proList = Process.GetProcesses();

            foreach (Process pro in proList)
            {
                pro.Refresh();
                string[] str1 =
                {
                    pro.ProcessName,
                    pro.Id.ToString(),
                ((double)(pro.PrivateMemorySize64/1024/1024)).ToString("#.##")+ "M",
                ((double)(pro.PrivateMemorySize64/1024/1024)).ToString("#.##")+ "M",
                (pro.WorkingSet64/1024/1024).ToString("#.##")+ "M"
                };

                listView1.Items.Add(new ListViewItem(str1));
            }

        }
    }

}