﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace ResourceRecorder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Stopwatch watchTime = Stopwatch.StartNew();

            GetCurrentInfo();
        }


        private void GetCurrentInfo()
        {
            listView1.Items.Clear();

            Process[] proList = Process.GetProcesses();

            foreach (Process pro in proList)
            {
                pro.Refresh();
                string[] str1 =
                {
                    pro.ProcessName,
                    pro.Id.ToString(),
                ((double)(pro.PrivateMemorySize64/1024/1024)).ToString("#.##")+ "M",
                ((double)(pro.PrivateMemorySize64/1024/1024)).ToString("#.##")+ "M",
                (pro.WorkingSet64/1024/1024).ToString("#.##")+ "M"
                };

                listView1.Items.Add(new ListViewItem(str1));
            }

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
