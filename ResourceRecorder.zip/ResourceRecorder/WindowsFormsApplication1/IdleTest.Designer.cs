﻿namespace ResourceRecorder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.listView1 = new System.Windows.Forms.ListView();
            this.clnName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clnPID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clnWorkingSet = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clnPrivate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clnHandle = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clnThreads = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.AllowColumnReorder = true;
            this.listView1.AllowDrop = true;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clnName,
            this.clnPID,
            this.clnWorkingSet,
            this.clnPrivate,
            this.clnHandle,
            this.clnThreads});
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(44, 38);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(922, 425);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listView1_ColumnClick);
            // 
            // clnName
            // 
            this.clnName.Text = "名称";
            this.clnName.Width = 280;
            // 
            // clnPID
            // 
            this.clnPID.Text = "PID";
            this.clnPID.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // clnWorkingSet
            // 
            this.clnWorkingSet.Text = "Working Set";
            this.clnWorkingSet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.clnWorkingSet.Width = 100;
            // 
            // clnPrivate
            // 
            this.clnPrivate.Text = "Memory(Private Working Set)";
            this.clnPrivate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.clnPrivate.Width = 205;
            // 
            // clnHandle
            // 
            this.clnHandle.Text = "Handles";
            this.clnHandle.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.clnHandle.Width = 103;
            // 
            // clnThreads
            // 
            this.clnThreads.Text = "Threads";
            this.clnThreads.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.clnThreads.Width = 83;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1076, 554);
            this.Controls.Add(this.listView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "IdleTestMain";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader clnName;
        private System.Windows.Forms.ColumnHeader clnPID;
        private System.Windows.Forms.ColumnHeader clnWorkingSet;
        private System.Windows.Forms.ColumnHeader clnPrivate;
        private System.Windows.Forms.ColumnHeader clnHandle;
        private System.Windows.Forms.ColumnHeader clnThreads;
    }
}

