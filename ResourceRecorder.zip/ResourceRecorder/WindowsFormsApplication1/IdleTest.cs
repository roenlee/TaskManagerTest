﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Management;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using WindowsFormsApplication1;
using System.Collections;

namespace ResourceRecorder
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {
             Stopwatch watchTime = Stopwatch.StartNew();

             GetCurrentInfo();

            watchTime.Stop();
            //lbTime.Text=(watchTime.Elapsed).ToString();
        }

        #region 获取当前进程信息
        /// <summary>
        /// 获取当前进程信息
        /// </summary>
        public void GetCurrentInfo()
        {
            const int DIV_K = 1024;
           // const int DIV_M = 1024 * 1024;
            string ProcessName;
            string NameTotal="_Total";

            listView1.Items.Clear();

            //Process[] proList = Process.GetProcesses();

            var category = new PerformanceCounterCategory("Process");
            string[] names = category.GetInstanceNames();

            foreach (var proName in names)
            {
                
                //
                PerformanceCounter pfPriVate = new PerformanceCounter("Process", "Working Set - Private", proName);
                string ProcessWorkingSetPrivate = ((pfPriVate.NextValue()/DIV_K).ToString("N0")+"K");
                
                //
                PerformanceCounter pfWorkSet = new PerformanceCounter("Process", "Working Set", proName);
                string ProcessWorkingSet=((pfWorkSet.NextValue()/DIV_K).ToString("N0") + "K");

                //
                PerformanceCounter pfThreads = new PerformanceCounter("Process", "Thread Count", proName);
                string ProcessThread = pfThreads.NextValue().ToString("N0");

                //
                PerformanceCounter pfHandles = new PerformanceCounter("Process", "Handle Count", proName);
                string ProcessHandles = pfHandles.NextValue().ToString("N0");

                //
                PerformanceCounter pfId = new PerformanceCounter("Process", "ID process", proName);
                var ProcessId = pfId.NextValue().ToString();

                //
                ProcessName=string.Format(TrimString(proName).ToString());

                string[] str1 =
                    {
                    ProcessName,
                    ProcessId,
                    ProcessWorkingSet,
                    ProcessWorkingSetPrivate,
                    ProcessHandles,
                    ProcessThread

                    //(pfWorkSet.NextValue()/DIV_K).ToString("N0")+ " K",
                   // (pfPriVate.NextValue()/DIV_K).ToString("N0")+ " K",
                   // (pfThreads.NextValue()).ToString("N0"),
                    //(pfHandles.NextValue()).ToString("N0")
                    };
                //  (pfHandles.NextValue()).ToString("N0"),
                //   (pfThreads.NextValue()).ToString("N0")
                //pro.Threads.ToString()
                // pro.Handle.ToString()
                if (proName!= NameTotal)
                {
                    listView1.Items.Add(new ListViewItem(str1));
                }
                
            }
        }

        private object TrimString(string name)
        {
            var pos = name.IndexOf('#');

            if (pos != -1)

                return name.Substring(0, pos);

            return name;
        }
        #endregion

        #region 列表排序
        /// <summary>
        /// 列表排序
        /// </summary>
        public class ListViewItemCompare:IComparer
        {
            private int col=0;
            public int Compare(object x,object y)
            {
                int returnVal = -1;
                returnVal = String.Compare(((ListViewItem)x).SubItems[col].Text, ((ListViewItem)y).SubItems[col].Text);
                return returnVal;
            }

        }





        #endregion

        #region 列表排序二
        
        
        #endregion


        private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            // this.listView1.ListViewItemSorter = new ListViewItemCompare();

            // listView1.Sort();
            if (listView1.Sorting==SortOrder.Ascending)
            {
                listView1.Sorting = SortOrder.Descending;
            }
            else
            {
                listView1.Sorting = SortOrder.Ascending;
            }
            
        }
    }

}